# Telegram Mini App V2

এই version-এ frontend-এর সাথে Node.js + SQLite backend যুক্ত করা হয়েছে।

### Features
- Telegram user ID ভিত্তিক user record
- Balance
- Task/reward
- Referral UI
- Withdraw request
- SQLite database

### চালাতে
1. Node.js install করুন।
2. `backend` folder-এ `npm install` চালান।
3. `npm start` চালান।
4. Production-এ HTTPS hosting ব্যবহার করুন।
5. Telegram Mini App হিসেবে URL সেট করুন।

### গুরুত্বপূর্ণ
এটি starter/demo backend। Production-এর আগে Telegram `initData` signature validation, authentication, admin authorization, rate limiting, HTTPS, fraud protection এবং withdrawal verification যোগ করতে হবে। Real money system সরাসরি এই demo code দিয়ে চালানো উচিত নয়।
