const express=require("express"),path=require("path"),Database=require("better-sqlite3");
const app=express(),db=new Database("app.db");app.use(express.json());app.use(express.static(path.join(__dirname,"../frontend")));
db.exec(`CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,name TEXT,balance REAL DEFAULT 0);
CREATE TABLE IF NOT EXISTS tasks(id TEXT PRIMARY KEY,title TEXT,reward REAL);
CREATE TABLE IF NOT EXISTS completions(user_id TEXT,task_id TEXT,PRIMARY KEY(user_id,task_id));
CREATE TABLE IF NOT EXISTS withdrawals(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT,amount REAL,phone TEXT,status TEXT,created_at TEXT);`);
const count=db.prepare("SELECT COUNT(*) c FROM tasks").get().c;
if(!count)db.prepare("INSERT INTO tasks VALUES(?,?,?)").run("task1","Demo Task",1);

function telegramUser(req){try{const raw=req.get("X-Telegram-Init-Data")||"";const m=raw.match(/(?:^|&)user=([^&]+)/);if(m)return JSON.parse(decodeURIComponent(m[1]));}catch(e){}return {id:"demo",first_name:"Demo"}}
app.use((req,res,next)=>{if(req.path.startsWith("/api")){const u=telegramUser(req);req.user=u;db.prepare("INSERT OR IGNORE INTO users(id,name,balance) VALUES(?,?,0)").run(String(u.id),u.first_name||"User")}next()});
app.get("/api/me",(req,res)=>res.json({ok:true,user:db.prepare("SELECT * FROM users WHERE id=?").get(String(req.user.id))}));
app.get("/api/tasks",(req,res)=>res.json({tasks:db.prepare("SELECT * FROM tasks").all()}));
app.post("/api/tasks/:id/complete",(req,res)=>{const id=String(req.user.id),tid=req.params.id,t=db.prepare("SELECT * FROM tasks WHERE id=?").get(tid);if(!t)return res.status(404).json({message:"Task not found"});try{db.prepare("INSERT INTO completions VALUES(?,?)").run(id,tid);db.prepare("UPDATE users SET balance=balance+? WHERE id=?").run(t.reward,id);res.json({ok:true,message:"Task complete, reward added."})}catch(e){res.json({ok:false,message:"এই task আগে complete করা হয়েছে।"})}});
app.post("/api/withdraw",(req,res)=>{const amount=Number(req.body.amount),phone=String(req.body.phone||""),id=String(req.user.id),u=db.prepare("SELECT * FROM users WHERE id=?").get(id);if(!amount||amount<=0||amount>u.balance)return res.status(400).json({message:"Invalid amount or insufficient balance"});db.prepare("UPDATE users SET balance=balance-? WHERE id=?").run(amount,id);db.prepare("INSERT INTO withdrawals(user_id,amount,phone,status,created_at) VALUES(?,?,?,?,datetime('now'))").run(id,amount,phone,"pending");res.json({ok:true,message:"Withdraw request submitted."})});
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"../frontend/index.html")));
app.listen(process.env.PORT||3000,()=>console.log("Mini App server running"));